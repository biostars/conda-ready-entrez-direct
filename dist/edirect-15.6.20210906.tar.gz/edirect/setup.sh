#!/bin/bash -norc

# Public domain notice for all NCBI EDirect scripts is located at:
# https://www.ncbi.nlm.nih.gov/books/NBK179288/#chapter6.Public_Domain_Notice

DIR="$( cd "$( dirname "$0" )" && pwd )"

cd "$DIR"

osname=`uname -s`
cputype=`uname -m`
case "$osname-$cputype" in
  Linux-x86_64 )           platform=Linux ;;
  Darwin-x86_64 )          platform=Darwin ;;
  Darwin-*arm* )           platform=Silicon ;;
  CYGWIN_NT-* | MINGW*-* ) platform=CYGWIN_NT ;;
  Linux-*arm* )            platform=ARM ;;
  * )                      platform=UNSUPPORTED ;;
esac

if [ -n "$platform" ]
then
  ./nquire -dwn ftp.ncbi.nlm.nih.gov entrez/entrezdirect xtract."$platform".gz
  gunzip -f xtract."$platform".gz
fi

if [ -f xtract."$platform" ]
then
  chmod +x xtract."$platform"
else
  echo "Unable to download xtract executable."
fi

if [ -n "$platform" ]
then
  ./nquire -dwn ftp.ncbi.nlm.nih.gov entrez/entrezdirect transmute."$platform".gz
  gunzip -f transmute."$platform".gz
fi

if [ -f transmute."$platform" ]
then
  chmod +x transmute."$platform"
else
  echo "Unable to download transmute executable."
fi

if [ -n "$platform" ]
then
  ./nquire -dwn ftp.ncbi.nlm.nih.gov entrez/entrezdirect rchive."$platform".gz
  gunzip -f rchive."$platform".gz
fi

if [ -f rchive."$platform" ]
then
  chmod +x rchive."$platform"
else
  echo "Unable to download rchive executable."
fi

echo ""
echo "Entrez Direct has been successfully downloaded and installed."
echo ""

prfx="In order to complete the configuration process, please execute the following:\n"
advice=`mktemp`

target=bash_profile
if ! grep "$target" "$HOME/.bashrc" >/dev/null 2>&1
then
  if [ ! -f $HOME/.$target ] || grep 'bashrc' "$HOME/.$target" >/dev/null 2>&1
  then
    target=bashrc
  else
    if [ -n "$prfx" ]
    then
      echo -e "$prfx"
      prfx=""
    fi
    echo "  echo \"source ~/.bash_profile\" >>" "\$HOME/.bashrc" | tee $advice
  fi
fi
if ! grep "PATH.*edirect" "$HOME/.$target" >/dev/null 2>&1
then
  if [ -n "$prfx" ]
  then
    echo -e "$prfx"
    prfx=""
  fi
  echo "  echo \"export PATH=\\\${PATH}:$DIR\" >>" "\$HOME/.$target" \
    | tee -a $advice
fi
zarget=zshrc
if [ "$osname" = "Darwin" ]
then
  if [ ! -f $HOME/.zshrc ] && [ -f $HOME/.zprofile ] >/dev/null 2>&1
  then
    zarget=zprofile
  fi
  if ! grep "PATH.*edirect" "$HOME/.$zarget" >/dev/null 2>&1
  then
    if [ -n "$prfx" ]
    then
      echo -e "$prfx"
      prfx=""
    fi
    echo "  echo \"export PATH=\\\${PATH}:$DIR\" >>" "\$HOME/.$zarget" \
      | tee -a $advice
  fi
fi

if [ -z "$prfx" ]
then
  echo ""
  if [ "$osname" = "Darwin" ]
  then
    echo "or manually edit the PATH variable assignments in your .$target and .$zarget files."
  else
    echo "or manually edit the PATH variable assignment in your .$target file."
  fi
  echo ""
  echo "Would you like to do that automatically now? [y/N]"
  read response
  case "$response" in
    [Yy]*      ) . $advice; echo "OK, done." ;;
    [Nn]* | '' ) echo "Holding off, then." ;;
    *          ) echo "Conservatively taking that as a no." ;;
  esac
fi
rm $advice
