// ===========================================================================
//
//                            PUBLIC DOMAIN NOTICE
//            National Center for Biotechnology Information (NCBI)
//
//  This software/database is a "United States Government Work" under the
//  terms of the United States Copyright Act. It was written as part of
//  the author's official duties as a United States Government employee and
//  thus cannot be copyrighted. This software/database is freely available
//  to the public for use. The National Library of Medicine and the U.S.
//  Government do not place any restriction on its use or reproduction.
//  We would, however, appreciate having the NCBI and the author cited in
//  any work or product based on this material.
//
//  Although all reasonable efforts have been taken to ensure the accuracy
//  and reliability of the software and data, the NLM and the U.S.
//  Government do not and cannot warrant the performance or results that
//  may be obtained by using this software or data. The NLM and the U.S.
//  Government disclaim all warranties, express or implied, including
//  warranties of performance, merchantability or fitness for any particular
//  purpose.
//
// ===========================================================================
//
// File Name:  fasta.go
//
// Author:  Jonathan Kans
//
// ==========================================================================

package eutils

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
)

// FASTARecord contains parsed data from FASTA format
type FASTARecord struct {
	SeqID    string
	Title    string
	Length   int
	Sequence string
}

// FASTAConverter partitions a FASTA set and sends records down a channel.
func FASTAConverter(inp io.Reader, caseSensitive bool) <-chan FASTARecord {

	if inp == nil {
		return nil
	}

	out := make(chan FASTARecord, chanDepth)
	if out == nil {
		fmt.Fprintf(os.Stderr, "\nERROR: Unable to create FASTA streamer channel\n")
		os.Exit(1)
	}

	// fastaStreamer splits FASTA input stream into individual records
	fastaStreamer := func(inp io.Reader, out chan<- FASTARecord) {

		// close channel when all records have been processed
		defer close(out)

		scanr := bufio.NewScanner(inp)

		seqid := ""
		title := ""

		var fasta []string

		sendFasta := func() {

			seq := strings.Join(fasta, "")
			seqlen := len(seq)

			if seqlen > 0 {
				out <- FASTARecord{SeqID: seqid, Title: title, Length: seqlen, Sequence: seq[:]}
			}

			seqid = ""
			title = ""
			// reset sequence accumulator
			fasta = nil
		}

		for scanr.Scan() {

			line := scanr.Text()
			if line == "" {
				break
			}

			if strings.HasPrefix(line, ">") {

				// send current record
				sendFasta()

				// process next defline
				line = line[1:]
				seqid, title = SplitInTwoLeft(line, " ")

				continue
			}

			if !caseSensitive {
				// optionally convert FASTA letters to upper case
				line = strings.ToUpper(line)
			}

			// leave only letters, asterisk, or hyphen
			line = strings.Map(func(c rune) rune {
				if c >= 'A' && c <= 'Z' {
					return c
				}
				if c >= 'a' && c <= 'z' {
					return c
				}
				if c == '*' || c == '-' {
					return c
				}
				return -1
			}, line)

			// append current line
			fasta = append(fasta, line)
		}

		// send final record
		sendFasta()
	}

	// launch single fasta streamer goroutine
	go fastaStreamer(inp, out)

	return out
}
